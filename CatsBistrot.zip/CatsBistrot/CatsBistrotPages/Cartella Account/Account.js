function logout() {
    // Rimuovi il token JWT dal localStorage
    localStorage.removeItem('authToken');

    // Reindirizza alla pagina iniziale (Campania.html)
    window.location.href = '../Campania.html';
}
