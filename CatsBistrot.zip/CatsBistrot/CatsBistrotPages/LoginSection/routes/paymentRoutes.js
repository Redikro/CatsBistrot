// routes/paymentsRoutes.js
const express = require('express');
const router = express.Router();
const paypal = require('@paypal/checkout-server-sdk');  // Aggiungi PayPal SDK

const environment = () => {
    const clientId = process.env.PAYPAL_CLIENT_ID;
    const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
    return new paypal.core.SandboxEnvironment(clientId, clientSecret);
};

const client = new paypal.core.PayPalHttpClient(environment());

router.post('/test-paypal', async (req, res) => {
    const request = new paypal.orders.OrdersCreateRequest();
    request.requestBody({
        intent: 'CAPTURE',
        purchase_units: [{
            amount: {
                currency_code: 'EUR',
                value: '5.00'
            }
        }],
        application_context: {
            return_url: 'http://localhost:3000/payment-success',
            cancel_url: 'http://localhost:3000/payment-cancelled'
        }
    });

    try {
        const order = await client.execute(request);
        res.json({ id: order.result.id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Something went wrong' });
    }
});

router.post('/capture-payment', async (req, res) => {
    const { orderId } = req.body;
    const request = new paypal.orders.OrdersCaptureRequest(orderId);
    request.requestBody({});

    try {
        const capture = await client.execute(request);
        res.json({ status: 'success', capture });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Payment capture failed' });
    }
});

module.exports = router;
