require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const paypal = require('@paypal/checkout-server-sdk');  // Aggiungi PayPal SDK
const paymentRoutes = require('./routes/paymentRoutes');  // Percorso corretto del file paymentRoutes.js

const app = express();
const port = process.env.PORT || 3000; // Porta di ascolto configurabile
const jwtSecret = process.env.JWT_SECRET || 'supersegreto'; // Chiave segreta per JWT

// Configurazione di PayPal SDK
function environment() {
    const clientId = process.env.PAYPAL_CLIENT_ID;
    const clientSecret = process.env.PAYPAL_CLIENT_SECRET;

    return new paypal.core.SandboxEnvironment(clientId, clientSecret);  // Usa Sandbox per i test
}

const client = new paypal.core.PayPalHttpClient(environment());

// Abilita CORS per tutte le origini o configurato per specifiche origini in produzione
app.use(cors());

// Configura il database PostgreSQL
const pool = new Pool({
    user: process.env.REDIKRO_DB_USER,
    host: process.env.REDIKRO_DB_HOST,
    database: process.env.REDIKRO_DB_NAME,
    password: process.env.REDIKRO_DB_PASSWORD,
    port: process.env.REDIKRO_DB_PORT,
});

// Middleware per analizzare JSON e form data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware per verificare il token JWT
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).send({ message: 'Accesso negato. Token mancante.' });

    jwt.verify(token, jwtSecret, (err, user) => {
        if (err) return res.status(403).send({ message: 'Token non valido.' });
        req.user = user;
        next();
    });
};

// Endpoint per il login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).send({ message: 'Email e password sono obbligatori.' });
    }

    try {
        const query = `SELECT id, nickname, email, password FROM users WHERE email = $1`;
        const result = await pool.query(query, [email]);

        if (result.rows.length === 0) {
            return res.status(401).send({ message: 'Credenziali non valide.' });
        }

        const user = result.rows[0];
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(401).send({ message: 'Credenziali non valide.' });
        }

        // Genera il token JWT
        const token = jwt.sign({ userId: user.id, nickname: user.nickname }, jwtSecret, { expiresIn: '1h' });

        res.status(200).send({ message: 'Login avvenuto con successo!', token });
    } catch (error) {
        console.error('Errore durante il login:', error);
        res.status(500).send({ message: 'Errore del server. Dettagli dell\'errore: ' + error.message });
    }
});

// Endpoint per la registrazione
app.post('/register', async (req, res) => {
    const { nickname, email, password, firstName, lastName, dateOfBirth } = req.body;

    if (!nickname || !email || !password || !firstName || !lastName || !dateOfBirth) {
        return res.status(400).send({ message: 'Tutti i campi sono obbligatori.' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const query = `
            INSERT INTO users (nickname, email, password, first_name, last_name, date_of_birth)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id;
        `;
        const values = [nickname, email, hashedPassword, firstName, lastName, dateOfBirth];

        const result = await pool.query(query, values);

        res.status(201).send({ message: 'Utente registrato con successo!', userId: result.rows[0].id });
    } catch (error) {
        console.error('Errore nella registrazione:', error);
        res.status(500).send({ message: 'Errore del server. Dettagli dell\'errore: ' + error.message });
    }
});

// Endpoint per il logout
app.post('/logout', authenticateToken, (req, res) => {
    res.status(200).send({ message: 'Logout effettuato con successo.' });
});

// Usa le rotte dei pagamenti
app.use('/api/payments', paymentRoutes);

app.post('/api/bookings', authenticateToken, async (req, res) => {
    const { booking_date, booking_time, table_number, number_of_people } = req.body;

    const userId = req.user?.userId; // Assicurati che 'id' venga estratto correttamente dal token

    if (!userId) {
        return res.status(400).json({ message: 'ID utente non trovato nel token' });
    }

    try {
        // Aggiungi la logica per inserire i dati della prenotazione nel database (PostgreSQL)
        const query =`
            INSERT INTO bookings (booking_date, booking_time, table_number, number_of_people, user_id)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *;
        `;
        const values = [booking_date, booking_time, table_number, number_of_people, userId];

        const result = await pool.query(query, values);

        res.status(200).json({ message: 'Prenotazione effettuata con successo!', bookings: result.rows[0] });
    } catch (err) {
        console.error('Errore nella prenotazione:', err);
        res.status(500).json({ message: 'Errore durante la prenotazione.' });
    }
});

console.log('Server is running');
// Endpoint POST per l'adozione
app.post('/api/adoptions', authenticateToken, async (req, res) => {

    console.log('Post request received');
    const { catId, adoptionDate } = req.body;  // Dati dal form
    const userId = req.user?.userId; // Assicurati che 'id' venga estratto correttamente dal token

    if (!userId) {
        return res.status(400).json({ message: 'ID utente non trovato nel token' });
    }

    if (!catId || !adoptionDate) {
        return res.status(400).json({ message: 'Cat ID and adoption date are required.' });
    }

    try {
        // Inserimento nella tabella adoptions
        const query = `INSERT INTO adoptions (user_id, cat_id, adoption_date) VALUES ($1, $2, $3) RETURNING id_ad`;

        const values = [userId, catId, adoptionDate];
        const result = await pool.query(query, values);

        // Aggiornamento stato del gatto (adopted)
        const updateQuery = `UPDATE cats SET adopted = true WHERE id_cat = $1`;
        await pool.query(updateQuery, [catId]);

        res.status(201).json({ message: 'Adoption successful!', adoptionId: result.rows[0].id_ad });
    } catch (err) {
        console.error('Error completing adoption:', err);
        res.status(500).json({ message: 'Error completing adoption.' });
    }
});




app.get('/adoptions/cats', async (req, res) => {
    try {
        // Usa pool per eseguire la query al database
        const result = await pool.query(`SELECT id_cat, name, age, breed FROM cats WHERE adopted = FALSE`);

        // Restituisci i gatti non adottati come JSON
        res.json(result.rows);
    } catch (error) {
        console.error('Errore nel recuperare i gatti:', error);
        res.status(500).json({ error: 'Impossibile recuperare i gatti al momento.' });
    }
});




// Avvia il server
app.listen(port, () => {
    console.log(`Server in ascolto su http://localhost:${port}`);
});
