const paypal = require('../config/paypalConfig');

// Crea il pagamento
exports.createPayment = (req, res) => {
    const createPaymentJson = {
        intent: 'sale',
        payer: {
            payment_method: 'paypal',
        },
        redirect_urls: {
            return_url: 'http://localhost:3000/api/payments/success',
            cancel_url: 'http://localhost:3000/api/payments/cancel',
        },
        transactions: [{
            amount: {
                currency: 'EUR',
                total: '5.00', // Sostituisci con il totale dinamico
            },
            description: 'Acquisto al Cats Bistrot',
        }],
    };

    paypal.payment.create(createPaymentJson, (error, payment) => {
        if (error) {
            console.error(error);
            res.status(500).send({ message: 'Errore nella creazione del pagamento.' });
        } else {
            for (let link of payment.links) {
                if (link.rel === 'approval_url') {
                    return res.status(200).send({ approvalUrl: link.href });
                }
            }
        }
    });
};

// Conferma il pagamento
exports.executePayment = (req, res) => {
    const { paymentId, PayerID } = req.query;

    const executePaymentJson = {
        payer_id: PayerID,
    };

    paypal.payment.execute(paymentId, executePaymentJson, (error, payment) => {
        if (error) {
            console.error(error.response);
            res.status(500).send({ message: 'Errore durante la conferma del pagamento.' });
        } else {
            res.sendFile(__dirname + '/views/paymentSuccess.html');
        }
    });
};

// Annulla il pagamento
exports.cancelPayment = (req, res) => {
    res.sendFile(__dirname + '/views/paymentCancel.html');
};
