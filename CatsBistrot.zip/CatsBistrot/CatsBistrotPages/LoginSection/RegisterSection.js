document.addEventListener('DOMContentLoaded', function () {
    document.querySelector("#register-form").addEventListener("submit", async (event) => {
        event.preventDefault();

        // Ottieni i valori dei campi
        const nicknameField = document.querySelector('input[name="nickname"]');
        const emailField = document.querySelector('input[name="email"]');
        const passwordField = document.querySelector('input[name="password"]');
        const firstNameField = document.querySelector('input[name="first-name"]');
        const lastNameField = document.querySelector('input[name="last-name"]');
        const birthdateField = document.querySelector('input[name="birthdate"]');

        // Verifica che tutti i campi siano trovati
        if (!nicknameField || !emailField || !passwordField || !firstNameField || !lastNameField || !birthdateField) {
            console.error("Uno o più campi del modulo non sono stati trovati.");
            return;
        }

        // Ottieni i valori
        const nickname = nicknameField.value;
        const email = emailField.value;
        const password = passwordField.value;
        const firstName = firstNameField.value;
        const lastName = lastNameField.value;
        const birthdate = birthdateField.value;

        // Crea l'oggetto dati
        const data = {
            nickname,
            email,
            password,
            firstName,
            lastName,
            dateOfBirth: birthdate,
        };

        try {
            // Effettua la richiesta POST
            const response = await fetch("http://localhost:3000/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message);
            }

            const result = await response.json();
            alert("Registrazione avvenuta con successo!");
            console.log(result);
            window.location.href = 'LoginSection.html'
        } catch (error) {
            alert("Errore nella registrazione: " + error.message);
        }
    });
});
