document.addEventListener("DOMContentLoaded", () => {
    const dropdownTrigger = document.querySelector(".dropdown-trigger");
    const dropdown = document.querySelector(".dropdown");

    // Aggiungi un evento al click sul tasto del menu
    dropdownTrigger.addEventListener("click", () => {
        // Toglia o aggiungi la classe "open" per mostrare/nascondere il menu
        dropdown.classList.toggle("open");
    });
});

