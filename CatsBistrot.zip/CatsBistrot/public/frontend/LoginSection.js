document.getElementById('loginform').addEventListener('submit', async function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('authToken', data.token); // Salva il token nel localStorage
            alert('Login effettuato con successo!');
            window.location.href = 'Campania.html'; // Reindirizza alla pagina principale
        } else {
            const error = await response.json();
            alert('Errore: ' + error.message);
        }
    } catch (error) {
        console.error('Errore di rete:', error);
        alert('Si è verificato un errore durante la connessione al server.');
    }
});
