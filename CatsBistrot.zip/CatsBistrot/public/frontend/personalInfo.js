// Funzione per formattare la data senza l'ora
function formatDateWithoutTime(date) {
    const dateObj = new Date(date);

    // Fissa l'ora a mezzanotte nel fuso orario locale
    dateObj.setHours(0, 0, 0, 0);

    // Corregge il fuso orario locale per evitare il problema dei giorni
    const localDate = new Date(dateObj.getTime() - dateObj.getTimezoneOffset() * 60000);

    return localDate.toISOString().split('T')[0];  // Restituisce solo la parte della data (yyyy-mm-dd)
}

async function getUserInfo() {
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = 'login.html';  // Reindirizza al login se il token non è presente
        return;
    }

    try {
        const response = await fetch('/api/user', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
            }
        });

        if (!response.ok) {
            throw new Error('Errore nel recupero delle informazioni utente');
        }

        const data = await response.json();
        console.log(data);  // Aggiungi questo per verificare cosa contiene 'data'

        // Verifica che i dati non siano undefined/null prima di assegnarli
        if (data) {
            document.getElementById('nickname').value = data.nickname || '';
            document.getElementById('email').value = data.email || '';
            document.getElementById('firstName').value = data.first_name || '';
            document.getElementById('lastName').value = data.last_name || '';

            // Usa la funzione formatDateWithoutTime per formattare correttamente la data
            document.getElementById('dateOfBirth').value = formatDateWithoutTime(data.date_of_birth) || '';

            // Visualizza i dati correnti sopra il modulo
            document.getElementById('currentNickname').textContent = data.nickname || 'N/A';
            document.getElementById('currentEmail').textContent = data.email || 'N/A';
            document.getElementById('currentFirstName').textContent = data.first_name || 'N/A';
            document.getElementById('currentLastName').textContent = data.last_name || 'N/A';
            document.getElementById('currentDOB').textContent = formatDateWithoutTime(data.date_of_birth) || 'N/A';
        } else {
            console.error('I dati dell\'utente non sono disponibili');
        }
    } catch (error) {
        console.error('Errore:', error);
    }
}

async function updateUserInfo() {
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    const nickname = document.getElementById('nickname').value;
    const email = document.getElementById('email').value;
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const dateOfBirth = document.getElementById('dateOfBirth').value;

    // Format the date before sending to the server
    const formattedDateOfBirth = formatDateWithoutTime(dateOfBirth);

    try {
        const response = await fetch('/api/user/update', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                nickname,
                email,
                first_name: firstName,
                last_name: lastName,
                date_of_birth: formattedDateOfBirth  // Send formatted date
            })
        });

        if (response.ok) {
            // Se la richiesta è andata a buon fine, reindirizza alla pagina Campania.html
            window.location.href = 'Campania.html'; // Aggiungi il percorso corretto se necessario
        } else {
            const result = await response.json();
            alert(result.message || 'Errore durante l\'aggiornamento.');
            window.location.href = 'Campania.html'; // Aggiungi il percorso corretto se necessario
        }
    } catch (err) {
        console.error('Errore nella richiesta di aggiornamento:', err);
        alert('Errore interno del server.');
    }
}

// Aggiungi l'evento per l'aggiornamento delle informazioni quando il modulo viene inviato
document.getElementById('updateForm').addEventListener('submit', updateUserInfo);

// Carica le informazioni utente quando la pagina è pronta
window.addEventListener('DOMContentLoaded', getUserInfo);
