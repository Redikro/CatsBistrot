document.addEventListener("DOMContentLoaded", () => {
    // Menu a tendina
    const dropdownTrigger = document.querySelector(".dropdown-trigger");
    const dropdown = document.querySelector(".dropdown");
    checkAuthentication();  // Verifica se l'utente è autenticato

    // Aggiungi l'evento per il bottone utente (Account)
    const userIconButton = document.getElementById("userIconButton");
    if (userIconButton) {
        userIconButton.addEventListener("click", () => {
            window.location.href = "/Account.html";  // Redirige alla pagina Account.html
        });
    }

    dropdownTrigger.addEventListener("click", () => {
        dropdown.classList.toggle("open");
    });

    // Controllo stato di autenticazione
    checkAuthentication();  // Verifica se l'utente è autenticato
    pushStateForAuthenticatedUser();
});


// Funzione per mostrare i contenuti specifici
function showContent(sectionId) {
    const allContent = document.querySelectorAll('.content');
    allContent.forEach(content => content.classList.remove('active'));

    // Controllo token per le sezioni protette
    const protectedSections = ['adopt-me', 'booking'];
    const token = localStorage.getItem('authToken');

    if (protectedSections.includes(sectionId) && !token) {
        alert('Devi effettuare il login per accedere a questa sezione.');
        window.location.href = 'LoginSection.html';
        return;
    }

    const selectedContent = document.getElementById(sectionId);
    if (selectedContent) {
        selectedContent.classList.add('active');
    }
}

function checkAuthentication() {
    const token = localStorage.getItem('authToken');

    // Se c'è un token, significa che l'utente è autenticato
    if (token) {
        // Nascondi il tasto Login e mostra il tasto Account
        document.getElementById('loginButton').style.display = 'none';
        document.getElementById('userIconButton').style.display = 'inline-block';  // Mostra il tasto Account
    } else {
        // Se non c'è un token, mostra solo il tasto Login
        document.getElementById('loginButton').style.display = 'inline-block';
        document.getElementById('userIconButton').style.display = 'none';  // Nascondi il tasto Account
    }
}

// Esempio per manipolare la cronologia (utile per la navigazione personalizzata)
function pushStateForAuthenticatedUser() {
    const token = localStorage.getItem('authToken');

    if (token) {
        history.pushState({ isAuthenticated: true }, '', window.location.href);
    } else {
        history.pushState({ isAuthenticated: false }, '', window.location.href);
    }
}

async function handleBooking(event) {
    event.preventDefault(); // Evita il comportamento predefinito del form

    const bookingForm = document.getElementById('bookingForm');
    const formData = new FormData(bookingForm);

    // Crea un oggetto con i dati del form
    const data = {
        booking_date: formData.get('booking_date'),
        booking_time: formData.get('booking_time'),
        table_number: formData.get('table_number'),
        number_of_people: formData.get('number_of_people'),
    };

    try {
        // Ottieni il token JWT (assumendo che venga salvato nel localStorage)
        const token = localStorage.getItem('authToken');

        // Controlla se c'è un token
        if (!token) {
            alert('Devi essere autenticato per fare una prenotazione.');
            return;
        }

        const response = await fetch('http://localhost:3000/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify(data),
        });

        const result = await response.json();

        if (response.ok) {
            alert('Prenotazione effettuata con successo!');
        } else {
            alert('Errore: ' + result.message);
        }
    } catch (error) {
        console.error('Errore durante il salvataggio della prenotazione:', error);
        alert('Si è verificato un errore durante la prenotazione.');
    }
}

function showMenu(category, type) {
    // Nascondi tutte le sezioni
    const sections = document.querySelectorAll('.menu-section');
    sections.forEach(section => section.classList.remove('active'));

    // Mostra la sezione selezionata
    const sectionId = type === 'gatti' ? category : category + '-hoomans';
    const section = document.getElementById(sectionId);
    if (section) {
        section.classList.add('active');
    }
}


document.addEventListener('DOMContentLoaded', async () => {
    const catSelect = document.getElementById('catId');

    try {
        const response = await fetch('http://localhost:3000/adoptions/cats');
        if (!response.ok) throw new Error('Errore nel recuperare i gatti');

        const cats = await response.json();

        // Popola il select con le opzioni
        cats.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.id_cat;  // Usa id_cat come valore
            option.textContent = `${cat.name}`;  // Mostra il nome
            catSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Errore:', error);
        alert('Impossibile caricare i gatti al momento.');
    }
});


// Gestisce la sottomissione del form
async function handleAdoption(event) {
    event.preventDefault();  // Evita il comportamento predefinito del form

    // Raccogli i dati dal form
    const catId = document.getElementById('catId').value;  // ID del gatto selezionato
    const adoptionDate = document.getElementById('adoptionDate').value;  // Data di adozione


    // Verifica se entrambi i dati sono stati inseriti
    if (!catId || !adoptionDate) {
        alert('Please select a cat and an adoption date');
        return;
    }

    // Prepara i dati per la richiesta POST
    const adoptionData = {
        catId: catId,
        adoptionDate: adoptionDate
    };



    // Invia la richiesta al server
    try {

        // Ottieni il token JWT (assumendo che venga salvato nel localStorage)
        const token = localStorage.getItem('authToken');

        // Controlla se c'è un token
        if (!token) {
            alert('Devi essere autenticato per fare una adozione.');
            return;
        }
        console.log(token);

        const response = await fetch('http://localhost:3000/api/adoptions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(adoptionData)

        });
        console.log(response);

        // Controlla se la risposta è positiva
        if (!response.ok) {
            throw new Error('Errore nell\'adozione');
        }

        const result = await response.json();
        alert(result.message);  // Mostra il messaggio di successo
    } catch (error) {
        console.error('Adoption Error:', error);
        alert('Impossibile completare l\'adozione.');
    }
}


// Funzione per mostrare i dettagli del gatto
function showCatDetails(catId) {
    // Nascondi tutte le sezioni dei gatti
    const catSections = document.querySelectorAll('.cat-section');
    catSections.forEach(section => section.style.display = 'none');

    // Mostra solo la sezione selezionata
    const selectedCat = document.getElementById(catId);
    selectedCat.style.display = 'block';
}
