document.addEventListener('DOMContentLoaded', function() {
    // Aggiungiamo un listener per il submit del modulo
    var form = document.getElementById('regionForm');

    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Impedisce il comportamento di invio del modulo

            // Selezioniamo il valore della regione dal menu a tendina
            var region = document.querySelector('.regione').value;

            // Controlliamo se è stata selezionata una regione
            if ( region == "campania") {
                // Redirige alla pagina corrispondente alla regione
                window.location.href = "CatsBistrotPages/" + region + ".html";
            } else {
                window.location.href = "CatsBistrotPages/UnderConstruction.html";
            }
        });
    }
})